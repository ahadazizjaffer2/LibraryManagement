namespace librarymanagement.Dtos
{
    public class BorrowBookDto
    {
        public int UserId { get; set; }
        public int BookId { get; set; }
    }
}
