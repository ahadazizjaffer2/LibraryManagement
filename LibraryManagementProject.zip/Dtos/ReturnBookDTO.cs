namespace librarymanagement.Dtos
{
    public class ReturnBookDto
    {
        public int UserId { get; set; }
        public int BookId { get; set; }
    }
}
